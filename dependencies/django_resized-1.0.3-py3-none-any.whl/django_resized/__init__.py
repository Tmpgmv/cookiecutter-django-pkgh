from django_resized.forms import ResizedImageField  # noqa
